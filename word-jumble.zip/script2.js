var letters = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];
var word = {
    text: "lion",
    hint: "Animal that roars",
    components: ["l", "i", "o", "n"]
  }
var word2 = {
    text: "zebra",
    hint: "Animal with stripes",
    components: ["z", "e", "b", "r", "a"]
  }

var words = [word]

var numberOfButtons = 7 //max buttons on screen

function getButtonLetters(thisWord){
  var buttonLetters = thisWord.components;
  for(var i = buttonLetters.length; i < numberOfButtons; i++) {
    buttonLetters.push(letters[0]); // Need to make this random from array letters
  }

  return buttonLetters; 
}

$(document).ready(function() {

  var myWord = word2; //get your word somehow
  var buttonLetters = getButtonLetters(myWord);
  console.log(buttonLetters)

  $.each(buttonLetters, function(index, letter){
    var el = $('<button class="btn btn-default btn-letter" data-letter="'+letter+'">'
      +letter+'</button>')
    $('#letter-options').append(el)
  })

  $('.btn-letter').click(function(event){
    console.log(event.target)
    var el = $(event.target)
    console.log(el.data('letter'))
  })

  // $('#letter-options').html(buttonLetters)
})
